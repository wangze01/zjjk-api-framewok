class GlobalData(object):
    Cookie = None
    token = None
    userList = []
