"""
# -*- coding: utf-8 -*-
# @Time    : 2021-04-12 17:21:41
# @Author  : wang
# @File    :


#封装配置文件的方法

"""
import json

import pytest
import os
import sys



from Common.plugs.get_config import r_config
from Common.plugs.http_requests import BaseRequest
from Common.plugs.get_excle import DoExcle, split_list
from Common.plugs.get_log import Log

headers = { 'Content-Type': 'application/json;charset=UTF-8',
            'App-code':'ZJ-PUB-D-AN',
            }

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))

if sys.platform == "win32":
    conf_path = os.path.join(BASE_DIR, 'Common/conf/env_config.ini').replace('/', '\\')
else:
    conf_path = os.path.join(BASE_DIR, 'Common/conf/env_config.ini')

log_path = r_config(conf_path, "log", "log_path")
logger = Log(log_path)
test_case_path = r_config(conf_path, "test_case", "test_case_path")

DE = DoExcle(test_case_path, 'login')
caseList = split_list(DE.read_data())[0][0]

#caseList = split_list(DE.read_data())



@pytest.fixture(scope='class')
def start_module(project_module_start):
    logger.info("==========开始执行测试用例集===========")

    logger.info("开始执行 ------- {0} 用例".format(caseList['description']))

    ret = BaseRequest(url=caseList['url'], headers=project_module_start[0], method=caseList['method'],
                      data=json.dumps(caseList['parm'])).get_json()

    #将 token 加入到请求头中
    if ret['data'] != None and 'token' in ret['data']:
        headers['Commons-session'] = ret['data']['token']
        yield (headers, project_module_start[1])

    return project_module_start
    logger.info("==========结束执行测试用例集===========")

if __name__ == '__main__':
    a=start_module




if __name__ == '__main__':
    pass